package com.example.camerahook

import android.hardware.camera2.CameraManager
import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * IMPORTANT:
 * This is a safe/reference hook layer. It observes Camera2 initialization
 * and exposes a bridge point. It does NOT silently inject frames into TikTok.
 *
 * Actual frame replacement depends on the TikTok build and camera stack.
 */
class TikTokCameraHook : IXposedHookLoadPackage {
    companion object {
        private const val TAG = "CHP-HOOK"
        private const val TARGET = "com.zhiliaoapp.musically"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET) return

        XposedBridge.log("$TAG loaded in ${lpparam.packageName}")

        try {
            XposedHelpers.findAndHookMethod(
                CameraManager::class.java,
                "openCamera",
                String::class.java,
                android.hardware.camera2.CameraDevice.StateCallback::class.java,
                android.os.Handler::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val cameraId = param.args[0] as? String ?: "?"
                        XposedBridge.log("$TAG CameraManager.openCamera id=$cameraId")
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("$TAG hook failed: $t")
        }

        // The production adapter should be implemented here for the
        // exact TikTok version/camera pipeline being targeted.
        // Recommended boundary:
        // Camera2 -> Surface/ImageReader -> frame adapter -> CHP IPC.
    }
}
