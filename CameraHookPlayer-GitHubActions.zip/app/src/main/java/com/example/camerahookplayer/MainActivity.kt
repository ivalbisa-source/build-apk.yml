package com.example.camerahookplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var status: TextView
    private var server: FrameServer? = null

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        status.text = "Video siap: $uri"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        val view = findViewById<androidx.media3.ui.PlayerView>(R.id.player)

        player = ExoPlayer.Builder(this).build().also {
            it.repeatMode = Player.REPEAT_MODE_ONE
            view.player = it
        }

        findViewById<Button>(R.id.selectButton).setOnClickListener {
            pickVideo.launch("video/*")
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (server == null) server = FrameServer().also { it.start() }
            player.repeatMode = Player.REPEAT_MODE_ONE
            player.play()
            status.text = "START: player aktif, IPC frame server berjalan"
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            player.pause()
            server?.stop()
            server = null
            status.text = "STOP"
        }
    }

    override fun onDestroy() {
        server?.stop()
        player.release()
        super.onDestroy()
    }
}
