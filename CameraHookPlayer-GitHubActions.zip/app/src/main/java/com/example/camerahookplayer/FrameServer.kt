package com.example.camerahookplayer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.util.Log
import android.view.Surface
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Reference IPC server.
 *
 * This sample sends a test JPEG frame to a connected hook client.
 * A production implementation should render the player's video frame
 * into an ImageReader/Surface and encode each frame as YUV or JPEG.
 */
class FrameServer {
    companion object {
        const val PORT = 38741
        const val MAGIC = 0x43485031 // CHP1
    }

    private val running = AtomicBoolean(false)
    private val pool = Executors.newCachedThreadPool()
    private var serverSocket: ServerSocket? = null

    fun start() {
        if (!running.compareAndSet(false, true)) return
        pool.execute {
            try {
                serverSocket = ServerSocket(PORT, 1, java.net.InetAddress.getByName("127.0.0.1"))
                while (running.get()) {
                    val socket = serverSocket!!.accept()
                    pool.execute { clientLoop(socket) }
                }
            } catch (t: Throwable) {
                if (running.get()) Log.e("CHP", "server", t)
            }
        }
    }

    private fun clientLoop(socket: Socket) {
        socket.use { s ->
            val out = BufferedOutputStream(s.getOutputStream())
            // Protocol: MAGIC(4) + width(4) + height(4) + jpegLength(4) + jpegBytes.
            // This placeholder frame is deliberately not a camera replacement.
            while (running.get() && !s.isClosed) {
                val jpeg = TestFrame.jpeg()
                val header = ByteBuffer.allocate(16)
                    .putInt(MAGIC)
                    .putInt(TestFrame.W)
                    .putInt(TestFrame.H)
                    .putInt(jpeg.size)
                    .array()
                out.write(header)
                out.write(jpeg)
                out.flush()
                SystemClock.sleep(1000L / 15L)
            }
        }
    }

    fun stop() {
        running.set(false)
        try { serverSocket?.close() } catch (_: Throwable) {}
        serverSocket = null
    }
}

private object TestFrame {
    const val W = 640
    const val H = 360

    fun jpeg(): ByteArray {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawColor(android.graphics.Color.DKGRAY)
        val stream = java.io.ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        bmp.recycle()
        return stream.toByteArray()
    }
}
