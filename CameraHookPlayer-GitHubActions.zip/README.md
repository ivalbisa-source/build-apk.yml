# Camera Hook Player

Proyek contoh Android Studio dengan dua APK:

- `app`: pemutar video + audio dengan loop dan START/STOP.
- `hook`: modul LSPosed/Xposed yang dimuat pada proses TikTok dan mengamati Camera2.

## Penting

Bagian `hook` di proyek ini sengaja berhenti pada boundary Camera2. Mengganti frame kamera TikTok secara universal tidak dapat dijamin hanya dengan satu hook `CameraManager.openCamera`, karena TikTok dapat memakai Camera2, CameraX, native camera code, SurfaceTexture, ImageReader, atau jalur internal lain yang berubah antar versi.

`FrameServer` menyediakan protokol IPC TCP localhost sederhana:
MAGIC(4) | width(4) | height(4) | jpegLength(4) | jpegBytes

Untuk implementasi produksi, ganti `TestFrame.jpeg()` dengan renderer frame dari Media3 ke `Surface`/`ImageReader`, lalu buat adapter di modul hook untuk pipeline kamera yang benar-benar digunakan oleh versi TikTok target.

## Build

Gunakan Android Studio, JDK 17, lalu:

./gradlew :app:assembleDebug
./gradlew :hook:assembleDebug

APK:
- app/build/outputs/apk/debug/app-debug.apk
- hook/build/outputs/apk/debug/hook-debug.apk

Pasang `hook-debug.apk` melalui LSPosed, aktifkan untuk proses TikTok, lalu reboot/restart TikTok.

## Catatan audio

Player menggunakan ExoPlayer sehingga audio video ikut diputar pada perangkat. Audio injection ke jalur mikrofon TikTok adalah masalah terpisah dari video camera hook dan memerlukan adapter audio yang spesifik; proyek ini tidak berpura-pura bahwa audio otomatis menjadi mic TikTok.


## Build dari GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke branch `main`.
3. Buka tab **Actions**.
4. Pilih workflow **Build Android APKs**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil run dan bagian **Artifacts**.
7. Download `CameraHookPlayer-debug` atau `CameraHookModule-debug`.

Workflow akan membangun dua APK secara otomatis.

### Jika GitHub Actions gagal pada `./gradlew`

Project harus memiliki `gradlew`, `gradlew.bat`, dan folder `gradle/wrapper`.
Jika wrapper tidak tersedia pada ZIP, buka project sekali pada Android Studio/AndroidIDE/Gradle environment untuk membuat wrapper, lalu upload kembali file wrapper tersebut.

### Catatan fungsi Camera Hook

Build yang berhasil tidak berarti frame video otomatis menggantikan kamera TikTok. Modul hook yang disertakan adalah reference implementation untuk Camera2 dan perlu adapter khusus untuk pipeline kamera versi TikTok yang ditargetkan.
